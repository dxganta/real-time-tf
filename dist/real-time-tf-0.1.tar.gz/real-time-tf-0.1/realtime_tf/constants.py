srate = 256
channel_labels = ['TP9', 'AF7', 'AF8', 'TP10']